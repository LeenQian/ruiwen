//
//  UILabel+ZZ.h
//  Friends Of Circle
//
//  Created by xy on 16/4/8.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (ZZ)

- (instancetype)initZZWithFontSize:(int)fontSize TextAlignment:(NSTextAlignment)alignment TextColor:(UIColor *)textColor;

- (instancetype)initZZWithFrame:(CGRect)frame FontSize:(int)fontSize TextAlignment:(NSTextAlignment)alignment TextColor:(UIColor *)textColor;
@end
