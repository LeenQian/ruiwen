//
//  UILabel+ZZ.m
//  Friends Of Circle
//
//  Created by xy on 16/4/8.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import "UILabel+ZZ.h"

@implementation UILabel (ZZ)

- (instancetype)initZZWithFontSize:(int)fontSize TextAlignment:(NSTextAlignment)alignment TextColor:(UIColor *)textColor
{
   return [self initZZWithFrame:CGRectMake(0, 0, 0, 0) FontSize:fontSize TextAlignment:alignment TextColor:textColor];
}

- (instancetype)initZZWithFrame:(CGRect)frame FontSize:(int)fontSize TextAlignment:(NSTextAlignment)alignment TextColor:(UIColor *)textColor
{
    if (self = [super initWithFrame:frame]) {
        self.font = [UIFont systemFontOfSize:fontSize];
        self.textAlignment = alignment;
        self.textColor = textColor;
    }
    return self;
}

@end
