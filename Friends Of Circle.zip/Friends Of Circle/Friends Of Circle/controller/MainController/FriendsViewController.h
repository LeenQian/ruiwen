//
//  FriendsViewController.h
//  Friends Of Circle
//
//  Created by xy on 16/3/25.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import "BaseViewController.h"

@interface FriendsViewController : BaseViewController

@end
