//
//  TabBarViewController.m
//  Friends Of Circle
//
//  Created by xy on 16/3/24.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import "TabBarViewController.h"
#import "NavigationViewController.h"
#import "BaseViewController.h"
#import "MessageViewController.h"
#import "FriendsViewController.h"
#import "SurroundViewController.h"
#import "MeViewController.h"

@interface TabBarViewController ()

@end

@implementation TabBarViewController

- (instancetype)init
{
    if (self = [super init]) {
        
        NSArray *mainViewCtlTitleArr = @[@"消息",@"好友",@"周边",@"我"];
        NSArray *controllerClassStr = @[@"MessageViewController",@"FriendsViewController",@"SurroundViewController",@"MeViewController"];
        NSArray *maintabBarItemImgStrArr = @[@"TabBar_Message",@"TabBar_Friends",@"TabBar_Surrounds",@"TabBar_Me"];
        NSMutableArray *tabBarViewControllersArr = [@[] mutableCopy];
        for (int i = 0;i<mainViewCtlTitleArr.count;i++) {
            BaseViewController *controller = [[NSClassFromString(controllerClassStr[i]) alloc] init];
            NavigationViewController *nav = [[NavigationViewController alloc] initWithRootViewController:controller];
            controller.title = mainViewCtlTitleArr[i];
            controller.tabBarItem = [[UITabBarItem alloc] initWithTitle:mainViewCtlTitleArr[i] image:[UIImage imageNamed:maintabBarItemImgStrArr[i]] selectedImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@_selected",maintabBarItemImgStrArr[i]]]];
            nav.customNavgationBar.titleLabel.text = mainViewCtlTitleArr[i];
            [tabBarViewControllersArr addObject:nav];
        }
        self.viewControllers = tabBarViewControllersArr;

    }
    
    return  self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"viewDidload");
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
