//
//  NavigationViewController.h
//  Friends Of Circle
//
//  Created by xy on 16/3/24.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationBar : UIView

@property (nonatomic, strong) UILabel *titleLabel;

@end

@interface NavigationViewController : UINavigationController

@property (nonatomic, strong) NavigationBar *customNavgationBar;

@end
