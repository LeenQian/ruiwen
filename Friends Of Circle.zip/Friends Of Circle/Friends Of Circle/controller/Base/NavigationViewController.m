//
//  NavigationViewController.m
//  Friends Of Circle
//
//  Created by xy on 16/3/24.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import "NavigationViewController.h"
#import "UILabel+ZZ.h"
@implementation NavigationBar

- (instancetype)init
{
    if (self = [super init]) {
        self.backgroundColor = RGB(60, 60, 60);
       
        self.titleLabel = [[UILabel alloc] initZZWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/3,22) FontSize:20 TextAlignment:NSTextAlignmentCenter TextColor:[UIColor whiteColor]];
         self.titleLabel.center = CGPointMake(SCREEN_WIDTH/2, 20+22);
        
        [self addSubview:self.titleLabel];
    }
    return self;
}

@end
@interface NavigationViewController ()

@end

@implementation NavigationViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    // Do any additional setup after loading the view.
}

- (void)initUI
{
    self.navigationBar.hidden = YES;
    _customNavgationBar = [[NavigationBar alloc] init];
    [self.view addSubview:_customNavgationBar];
    [_customNavgationBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(self.view);
        make.height.mas_equalTo(@(44+20));
        make.top.equalTo(self.view.mas_top).with.offset(0);
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//返回当前控制器状态栏字体颜色为白色
- (UIViewController *)childViewControllerForStatusBarStyle{
    return self.topViewController;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
