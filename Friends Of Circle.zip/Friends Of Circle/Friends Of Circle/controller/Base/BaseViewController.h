//
//  BaseViewController.h
//  Friends Of Circle
//
//  Created by xy on 16/3/24.
//  Copyright (c) 2016年 com.Lemon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
